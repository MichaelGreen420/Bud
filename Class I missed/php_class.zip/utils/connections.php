<?php
  
   //connect to mysql
    class Connections {
        public static $MYSQL;
        public static $LOG;
    }
    
?>
