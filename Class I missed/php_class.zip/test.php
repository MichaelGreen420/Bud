<?php
  phpinfo();
?>
